Fester's Quest: Redone
v1.0
By Retch

ABOUT
A gameplay-focused rebalance of Fester's Quest for the NES
This package contains an IPS patch for a clean USA game ROM and this README
The original cartridge artwork and music are preserved

GUN PROJECTILE LIFETIME COMPARISON
Tier   Original USA   Redone v1.0
1      20             20
2      24             21
3      32             23
4      35             24
5      40             26
6      48             27
7      48             29
8      30             30

These values are projectile lifetime counters, not exact pixel distances
The gun-range adjustment did not alter the existing shot damage or firing cadence code
A complete tier-by-tier enemy damage validation is still outstanding

FEATURES
- Eight gun upgrade tiers and four original whip upgrade tiers
- Gun projectile lifetime limits of 20 21 23 24 26 27 29 30 for tiers 1 through 8
- Gun tier 8 retains its original USA lifetime limit of 30
- Gameplay GUN meter with eight upgrade indicators
- Four visible full health bars at the start
- First original permanent health pickup adds one bar for five total
- Second original permanent health pickup adds one bar for six total
- Ordinary enemy hits remove one full visible health bar without half-bar damage
- Camera-synchronized normal walking speed of one pixel per frame in tested outdoor scrolling
- Stung walking movement tuned to 60 percent of normal movement
- Original game graphics, original music and original-style sprite flicker retained

HOW TO PATCH
- Back up your legally obtained clean Fester's Quest USA NES ROM
- Use an IPS-compatible patching utility to apply Festers_Quest_Redone_v10.ips
- Open the patched NES ROM in an NES emulator such as Mesen
- Start a new game instead of loading a savestate from a different hack build
- Do not apply this IPS to an already patched ROM

ROM CHECKSUMS
Clean USA CRC32: 4A269AB1
Alternate clean USA header CRC32: DB0C7019
Patched v1.0 CRC32: 7F4CAE61

COMPLETE CHANGELOG FOR THIS BUILD

Core gameplay and weapon progression
- Retained the existing eight-tier gun upgrade system and its gameplay GUN level display
- Rebalanced projectile lifetime limits to 20 21 23 24 26 27 29 30
- Kept gun tier 8 at the original USA lifetime limit
- Preserved the current gun shot patterns, damage code and firing cadence during the range adjustment
- Preserved all four original whip tiers without changing the whip's graphics or attack routines
- Retained the earlier Redone gameplay and item progression modifications in this branch

Health
- Set starting maximum health to four complete displayed bars
- Set each of the two original permanent upgrades to add one complete displayed bar
- Capped maximum health at six complete bars
- Changed ordinary enemy-hit damage to remove one full displayed bar, not half a bar
- Prevented repeated collection of an original permanent upgrade from exceeding the cap

Movement and status
- Retuned normal walking movement to one pixel per frame to match the tested scroll rate
- Retained stung movement at 60 percent of normal walking speed
- Preserved collision and walking animations during the movement adjustments

HUD and interface
- Retained the added eight-slot gameplay GUN meter
- Removed the additional vertical GUN meter from the inventory and CLUE screens
- Preserved the original inventory GUN and WHIP indicators
- Restored the gameplay meter after closing inventory
- Restricted menu cleanup to the added GUN HUD sprites instead of clearing unrelated artwork

Graphics and technical repairs
- Reverted the experimental sprite flicker and boss-underlay rendering changes
- Preserved all 131072 original CHR graphics bytes from the clean USA game
- Retained the repair for ROM program bytes incorrectly read as background screen data
- Retained the additional repair for the eight overwritten screen-data bytes near the menu transition
- Kept the original music tempo and pitch
- Avoided modifications to the original sprite artwork, menu art and enemy designs

KNOWN LIMITATIONS
- Original-style NES sprite flicker may still occur in crowded scenes
- Tested extensively, but bugs still may remain