Fester's Quest: Redone
v1.1
By Retch

ABOUT
A gameplay-focused rebalance of Fester's Quest for the NES, with eight gun
tiers, four whip tiers, an added gameplay GUN meter, and expanded health.
Original cartridge artwork and music are preserved.

GAMEPLAY
- Start with four full health bars. The two original permanent health pickups
  add one full bar each, for five and then six bars.
- Ordinary enemy hits remove one full health bar.
- Normal walking moves at one pixel per frame, with camera-synchronized scrolling.
- Stings reduce walking speed to 60% of normal and wear off after about two
  minutes of active play. The inventory screen shows the remaining sting time.
- Pausing stops the sting timer. Vice Grips cure the slowdown immediately.
- Recovery grants three seconds of protection against another sting.
- Potions and paid healing preserve supplies when health is full. Vice Grips
  are not consumed while healthy.
- Gun projectile lifetime limits by tier: 20, 21, 23, 24, 26, 27, 29, 30.
  These are lifetime counters rather than exact pixel distances.

HOW TO PATCH
1. Back up your legally obtained clean Fester's Quest (USA) NES ROM.
2. Apply Festers_Quest_Redone_v11.ips using an IPS-compatible patching tool.
3. Open the resulting patched NES ROM to play.
Apply this patch to the clean game, not over v1.0, v1.0a, or another hack.
The patched ROM uses expanded program space. Its file size is 393232 bytes.

SAVES
Back up existing battery saves before replacing your ROM.
Start from a fresh boot; do not load savestates made with an older ROM build.

ROM CHECKSUMS
Clean USA CRC32: 4A269AB1
Alternate clean USA header CRC32: DB0C7019
Patched v1.1 CRC32: 44D66759

CHANGELOG

v1.1
- Fixed corrupted backgrounds on the Addams family item-giver screens.
- Fixed the health display at five and six full bars and prevented a stall
  after permanent health upgrades.
- Restored original outdoor map cells and inventory background data.
- Expanded program space and moved added routines away from original screen data.
- Kept the gameplay GUN meter off inventory, NPC and ending screens.
- Moved GUN meter preparation out of the display update interrupt.
- Restored the inventory sting countdown, timed recovery and brief sting protection.
- Prevented wasted healing items, paid healing and healthy Vice Grip use.
- Cleared lingering sting and invisibility effects on new game/continue.
- Preserved v1.0a health, walking speed, gun lifetime limits and key-use repair.

v1.0a
- Fixed the key-use bug that could return the game to its title or intro.
- Restored the original key-use handler and moved the conflicting HUD helper.
- Preserved v1.0 gameplay balance, graphics, music and HUD layout.

v1.0
- Established the eight-tier gun and four-tier whip rebalance.
- Set gun lifetime limits to 20, 21, 23, 24, 26, 27, 29 and 30.
- Added the eight-indicator gameplay GUN meter while retaining the original
  inventory GUN and WHIP displays.
- Set starting health to four full bars, with permanent upgrades to five and six.
- Changed ordinary enemy damage to one complete health bar.
- Tuned normal walking to match camera scrolling, with stung speed at 60%.
- Retained the original artwork, music tempo and pitch, and original-style flicker.

Sprite flicker can still occur in crowded scenes and boss fights.
Original game by Sunsoft. ROM hack by Retch.
