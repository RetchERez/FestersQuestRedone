Fester's Quest: Redone
v10a
By Retch

v10a HOTFIX

This update fixes a release-blocking key-use bug in v10

WHAT WAS FIXED
- Restored the original Fester's Quest key-use handler byte-for-byte
- Removed the custom HUD trampoline that had overwritten the original key handler
- Relocated that HUD bank-switch helper into the existing safe Redone helper area
- Using a Key no longer sends the game back into the title or intro sequence
- Key and door behavior is reverted to the original game's behavior
- No health, gun, whip, movement, HUD layout, graphics, or music balance values were changed from v10

VERIFICATION
- The failure was reproduced on the released v10 ROM with CRC32 7F4CAE61 using a door and key gameplay checkpoint
- Under the same input sequence, v10 entered the intro or title sequence
- v10a remained in gameplay
- A 1200-frame key-use and menu regression remained in gameplay and completed normally
- The original key-handler bytes at CPU $CF93 are restored exactly
- The patch reconstructs the exact v10a ROM from both supported clean USA header variants

HOW TO PATCH
Apply Festers_Quest_Redone_v10a.ips to a clean USA Fester's Quest NES ROM
Do not apply it over v10 or another patched ROM
Start a new game instead of loading a savestate made with v10

ROM CHECKSUMS
Clean USA CRC32: 4A269AB1
Alternate clean USA header CRC32: DB0C7019
Patched Redone v10a CRC32: A56323EE
Patched Redone v10a SHA-256: ff24115367b3d4e7adac55c06c204be34d6b87a340ce5feb34341ac37fab0fe0

Original game by Sunsoft
ROM hack by Retch
